"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var http_1 = require("@angular/http");
require("rxjs/add/operator/map");
var SearchParameterUrl_1 = require("./SearchParameterUrl");
//import 'rxjs';
var PersonService = (function () {
    function PersonService(http) {
        this.http = http;
        this._localhost = "http://localhost:80";
        this._urlPersonAdd = this._localhost + "/api/person/addPerson";
        this._urlPersonList = this._localhost + "/api/person/list";
        this._urlPersonSearch = this._localhost + "/api/person/search";
        this.isLoading = false;
    }
    PersonService.prototype.addPerson = function (person) {
        return new Promise(function (resolve) {
            return resolve(false);
        });
    };
    ;
    PersonService.prototype.addPerson2 = function (person) {
        return this._http.post(this._urlPersonAdd, JSON.stringify(person)).map(function (data) { return data.json(); });
    };
    ;
    PersonService.prototype.listPerson = function () {
        return this._http.get(this._urlPersonList).map(function (data) { return data.json(); });
    };
    ;
    PersonService.prototype.search = function (firstname, lastname, age) {
        var _this = this;
        var searchUrlParser = new SearchParameterUrl_1.URLSearchParams();
        var searchUrl = searchUrlParser.getSearchParameter(firstname, lastname);
        return new Promise(function (resolve) {
            _this._http.get(_this._urlPersonSearch + searchUrl).map(function (x) { return x.json(); }).subscribe(function (y) {
                _this._dataSearch = y;
                resolve(_this._dataSearch);
            });
        });
    };
    return PersonService;
}());
PersonService = __decorate([
    core_1.Injectable(),
    __metadata("design:paramtypes", [http_1.Http])
], PersonService);
exports.PersonService = PersonService;
//# sourceMappingURL=PersonService.js.map
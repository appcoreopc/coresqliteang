"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var forms_1 = require("@angular/forms");
var core_1 = require("@angular/core");
var PersonService_1 = require("../services/PersonService");
var Person_1 = require("../Person");
require("rxjs/Rx");
var AddPersonComponent = (function () {
    function AddPersonComponent(personService, fb) {
        this.personService = personService;
        this.fb = fb;
        this.person = new Person_1.Person();
        this.formErrors = {
            'firstName': '',
            'lastName': '',
            'age': ''
        };
        this.validationMessages = {
            'firstName': {
                'required': 'First Name is required.',
                'minlength': 'Name must be at least 4 characters long.',
                'maxlength': 'Name cannot be more than 24 characters long.',
                'forbiddenName': 'Someone named "Bob" cannot be a hero.'
            },
            'lastName': {
                'required': 'Last Name is required.',
            },
            'age': {
                'required': 'Age is required.'
            }
        };
    }
    AddPersonComponent.prototype.ngOnInit = function () {
        this.initForm();
    };
    AddPersonComponent.prototype.initForm = function () {
        var _this = this;
        this.personForm = this.fb.group({
            'firstName': [this.person.firstName, [forms_1.Validators.required]],
            'lastName': [this.person.lastName, [forms_1.Validators.required]],
            'age': [this.person.age, [forms_1.Validators.required]],
        });
        this.personForm.valueChanges
            .subscribe(function (data) { return _this.onValueChanged(data); });
    };
    AddPersonComponent.prototype.onValueChanged = function (data) {
        if (!this.personForm) {
            return;
        }
        var form = this.personForm;
        for (var field in this.formErrors) {
            // clear previous error message (if any)
            this.formErrors[field] = '';
            var control = form.get(field);
            if (control && control.dirty && !control.valid) {
                var messages = this.validationMessages[field];
                for (var key in control.errors) {
                    this.formErrors[field] += messages[key] + ' ';
                }
            }
        }
    };
    AddPersonComponent.prototype.addPerson = function () {
        var p = new Person_1.Person({
            firstName: '',
            lastName: "",
            age: 12
        });
        this.personService.addPerson(p);
    };
    AddPersonComponent.prototype.onSubmit = function (person) {
        var _this = this;
        return this.personService.addPerson(person).then(function (statusResult) { return _this.status = statusResult; });
    };
    AddPersonComponent.prototype.onSubmit2 = function (person) {
        return this.personService.addPerson2(person);
    };
    return AddPersonComponent;
}());
AddPersonComponent = __decorate([
    core_1.Component({
        selector: 'my-app',
        templateUrl: './AddPersonComponent.html'
    }),
    __metadata("design:paramtypes", [PersonService_1.PersonService,
        forms_1.FormBuilder])
], AddPersonComponent);
exports.AddPersonComponent = AddPersonComponent;
//# sourceMappingURL=addPersonComponent.js.map
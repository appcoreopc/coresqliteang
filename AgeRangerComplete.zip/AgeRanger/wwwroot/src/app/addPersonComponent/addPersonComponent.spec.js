"use strict";
var testing_1 = require("@angular/core/testing");
var platform_browser_1 = require("@angular/platform-browser");
var addPersonComponent_1 = require("./addPersonComponent");
var PersonService_1 = require("../services/PersonService");
var http_1 = require("@angular/http");
var forms_1 = require("@angular/forms");
var common_1 = require("@angular/common");
var forms_2 = require("@angular/forms");
var Person_1 = require("../Person");
var Observable_1 = require("rxjs/Observable");
require("rxjs/add/observable/of");
require("rxjs/add/operator/delay");
require("jasmine");
describe('AddPersonComponent', function () {
    var comp;
    var fixture;
    var de;
    var el;
    var personService;
    var spy;
    // async beforeEach
    beforeEach(testing_1.async(function () {
        testing_1.TestBed.configureTestingModule({
            imports: [
                http_1.HttpModule, forms_1.ReactiveFormsModule, common_1.CommonModule, forms_2.FormsModule
            ],
            declarations: [addPersonComponent_1.AddPersonComponent],
            providers: [PersonService_1.PersonService],
        }).compileComponents();
    }));
    // synchronous beforeEach
    beforeEach(function () {
        fixture = testing_1.TestBed.createComponent(addPersonComponent_1.AddPersonComponent);
        personService = fixture.debugElement.injector.get(PersonService_1.PersonService);
        personService = testing_1.TestBed.get(PersonService_1.PersonService);
        spy = spyOn(personService, 'addPerson').and.returnValue(Promise.resolve(true));
        spy = spyOn(personService, 'addPerson2').and.returnValue(Observable_1.Observable.of(true));
    });
    it('submit button is rendered', function () {
        fixture.detectChanges();
        de = fixture.debugElement.query(platform_browser_1.By.css("#submit"));
        expect(de.attributes["type"]).toContain('submit');
    });
    it('rendered controls - firstname, lastname and age', function () {
        fixture.detectChanges();
        expect(fixture.debugElement.query(platform_browser_1.By.css("#firstname")).attributes["id"]).toContain('firstname');
        expect(fixture.debugElement.query(platform_browser_1.By.css("#lastname")).attributes["id"]).toContain('lastname');
        expect(fixture.debugElement.query(platform_browser_1.By.css("#age")).attributes["id"]).toContain('age');
    });
    it('add person successful', testing_1.async(function () {
        var targetComponent = fixture.componentInstance;
        var fakePerson = new Person_1.Person({
            firstName: '',
            lastName: '',
            age: 12
        });
        fixture.detectChanges();
        var submitResult = targetComponent.onSubmit(fakePerson);
        submitResult.then(function (a) {
            fixture.whenStable().then(function () {
                expect(a).toBe(true);
            });
        });
    }));
    it('person2', testing_1.async(function () {
        var targetComponent = fixture.componentInstance;
        var fakePerson = new Person_1.Person({
            firstName: '',
            lastName: '',
            age: 12
        });
        fixture.detectChanges();
        var submitResult = targetComponent.onSubmit2(fakePerson);
        submitResult.subscribe(function (r) {
            fixture.whenStable().then(function () {
                console.log(r);
                expect(r).toBe(true);
            });
        });
    }));
});
//# sourceMappingURL=addPersonComponent.spec.js.map
"use strict";
var testing_1 = require("@angular/core/testing");
var platform_browser_1 = require("@angular/platform-browser");
var searchComponent_1 = require("./searchComponent");
var PersonService_1 = require("../services/PersonService");
var http_1 = require("@angular/http");
var forms_1 = require("@angular/forms");
var common_1 = require("@angular/common");
var forms_2 = require("@angular/forms");
require("rxjs/add/operator/debounceTime");
require("rxjs/add/operator/map");
require("rxjs/add/operator/distinctUntilChanged");
describe('AddPersonComponent (templateUrl)', function () {
    var fixture;
    var de;
    var el;
    // async beforeEach
    beforeEach(testing_1.async(function () {
        testing_1.TestBed.configureTestingModule({
            imports: [
                http_1.HttpModule, forms_1.ReactiveFormsModule, common_1.CommonModule, forms_2.FormsModule
            ],
            declarations: [searchComponent_1.SearchComponent],
            providers: [PersonService_1.PersonService],
        }).compileComponents();
    }));
    // synchronous beforeEach
    beforeEach(function () {
        fixture = testing_1.TestBed.createComponent(searchComponent_1.SearchComponent);
    });
    it('component loaded', function () {
        fixture.detectChanges();
        var de = fixture.debugElement.query(platform_browser_1.By.css("h2"));
        el = de.nativeElement;
        expect(el.innerHTML).toContain("Search Person List");
    });
    it('rendered controls - firstname and lastname', function () {
        fixture.detectChanges();
        expect(fixture.debugElement.query(platform_browser_1.By.css("#firstname")).attributes["id"]).toContain('firstname');
        expect(fixture.debugElement.query(platform_browser_1.By.css("#lastname")).attributes["id"]).toContain('lastname');
    });
});
//# sourceMappingURL=searchComponent.spec.js.map
﻿
namespace AgeRanger.Config
{
    public class AppModuleConfig
    {
        public AppModuleConfig()
        {

        }

        public Defaults Defaults { get; set; }

        public Data Data { get; set; }
    }
}

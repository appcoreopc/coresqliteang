"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var PersonService_1 = require("../services/PersonService");
var core_1 = require("@angular/core");
var forms_1 = require("@angular/forms");
var SearchComponent = (function () {
    function SearchComponent(personService) {
        this.personService = personService;
        this.firstname = new forms_1.FormControl();
        this.lastname = new forms_1.FormControl();
    }
    SearchComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.firstname.valueChanges
            .debounceTime(400)
            .distinctUntilChanged()
            .subscribe(function (term) {
            console.log(_this.firstname.value);
        });
        this.lastname.valueChanges
            .debounceTime(400)
            .distinctUntilChanged()
            .subscribe(function (term) {
            console.log(_this.lastname.value);
        });
    };
    return SearchComponent;
}());
SearchComponent = __decorate([
    core_1.Component({
        selector: 'my-app',
        templateUrl: "./searchComponent.html"
    }),
    __metadata("design:paramtypes", [PersonService_1.PersonService])
], SearchComponent);
exports.SearchComponent = SearchComponent;
//# sourceMappingURL=searchComponent.js.map
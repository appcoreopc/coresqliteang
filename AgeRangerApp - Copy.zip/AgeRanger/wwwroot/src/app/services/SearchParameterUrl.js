"use strict";
var URLSearchParams = (function () {
    function URLSearchParams() {
        this.isQuestionMarkParsed = false;
        this.paramIdx = 0;
    }
    URLSearchParams.prototype.getSearchParameter = function (firstname, lastname) {
        this.setFirstName(firstname);
        this.setLastName(lastname);
        return this.ParseUrl;
    };
    URLSearchParams.prototype.setFirstName = function (firstname) {
        this.setQuestionMark();
        if (firstname) {
            this.ParseUrl("firstname=" + firstname);
        }
    };
    URLSearchParams.prototype.setLastName = function (lastname) {
        this.setQuestionMark();
        if (lastname)
            this.ParseUrl("lastname=" + lastname);
    };
    URLSearchParams.prototype.setQuestionMark = function () {
        if (!this.isQuestionMarkParsed) {
            this.parseUrl = "?";
            this.isQuestionMarkParsed = true;
        }
    };
    URLSearchParams.prototype.ParseUrl = function (param) {
        if (this.paramIdx > 0) {
            this.parseUrl = param;
        }
        this.paramIdx++;
    };
    return URLSearchParams;
}());
exports.URLSearchParams = URLSearchParams;
//# sourceMappingURL=SearchParameterUrl.js.map
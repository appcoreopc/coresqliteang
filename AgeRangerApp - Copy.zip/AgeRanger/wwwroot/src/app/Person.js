"use strict";
var Person = (function () {
    function Person(name) {
        Object.assign(this, name);
    }
    return Person;
}());
exports.Person = Person;
//# sourceMappingURL=Person.js.map
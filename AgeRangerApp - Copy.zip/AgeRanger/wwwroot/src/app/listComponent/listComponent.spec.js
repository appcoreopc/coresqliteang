"use strict";
var testing_1 = require("@angular/core/testing");
var platform_browser_1 = require("@angular/platform-browser");
var listComponent_1 = require("./listComponent");
var PersonService_1 = require("../services/PersonService");
var http_1 = require("@angular/http");
var common_1 = require("@angular/common");
describe('ListComponent', function () {
    var fixture;
    var de;
    var el;
    // async beforeEach
    beforeEach(testing_1.async(function () {
        testing_1.TestBed.configureTestingModule({
            imports: [
                http_1.HttpModule, common_1.CommonModule
            ],
            declarations: [listComponent_1.ListComponent],
            providers: [PersonService_1.PersonService],
        }).compileComponents();
    }));
    // synchronous beforeEach
    beforeEach(function () {
        fixture = testing_1.TestBed.createComponent(listComponent_1.ListComponent);
    });
    it('Person List component loaded', function () {
        fixture.detectChanges();
        de = fixture.debugElement.query(platform_browser_1.By.css("h2"));
        el = de.nativeElement;
        expect(el.innerText).toContain('Person List');
    });
});
//# sourceMappingURL=listComponent.spec.js.map
﻿
namespace AgeRanger.Config
{
    public class DefaultConnection
    {
        public string ConnectionString { get; set; }
    }
}
